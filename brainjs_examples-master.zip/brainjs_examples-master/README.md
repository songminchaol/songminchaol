# Brain.js Simple Examples

> These are some very basic examples from the YouTube "Simple Machine Learning Using JS" tutorial on YouTube.

## Adding Examples / Pull Requests

Feel free to add some examples. Just create a new file, number and label it and add your code/training data, etc. Please leave comments to explain what your network does
